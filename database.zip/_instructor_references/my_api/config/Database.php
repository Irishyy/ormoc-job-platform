<?php

class Database
{
    private $host = "localhost";
    private $dbname = "my_api";
    private $username = "root";
    private $password = "";

    public $conn;

    public function connect()
    {
        $this->conn = new mysqli(
            $this->host,
            $this->username,
            $this->password,
            $this->dbname
        );

        if ($this->conn->connect_error) {
            die(json_encode([
                "success" => false,
                "message" => "Database Connection Failed"
            ]));
        }

        return $this->conn;
    }
}