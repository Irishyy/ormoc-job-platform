<?php

require_once __DIR__ . "/../config/Database.php";
require_once __DIR__ . "/../models/User.php";
require_once __DIR__ . "/../utils/Response.php";

class UserController
{
    private $user;

    public function __construct()
    {
        $database = new Database();
        $db = $database->connect();

        $this->user = new User($db);
    }

    // CREATE
    public function store($data)
    {
        if (
            empty($data['name']) ||
            empty($data['email'])
        ) {
            Response::json(false, "All fields are required", null, 400);
        }

        $created = $this->user->create(
            $data['name'],
            $data['email']
        );

        if ($created) {
            Response::json(true, "User created successfully");
        }

        Response::json(false, "Failed to create user", null, 500);
    }

    // READ ALL
    public function index()
    {
        $users = $this->user->getAll();

        Response::json(true, "Users fetched successfully", $users);
    }

    // READ SINGLE
    public function show($id)
    {
        $user = $this->user->getById($id);

        if (!$user) {
            Response::json(false, "User not found", null, 404);
        }

        Response::json(true, "User fetched successfully", $user);
    }

    // UPDATE
    public function update($id, $data)
    {
        $updated = $this->user->update(
            $id,
            $data['name'],
            $data['email']
        );

        if ($updated) {
            Response::json(true, "User updated successfully");
        }

        Response::json(false, "Failed to update user", null, 500);
    }

    // DELETE
    public function destroy($id)
    {
        $deleted = $this->user->delete($id);

        if ($deleted) {
            Response::json(true, "User deleted successfully");
        }

        Response::json(false, "Failed to delete user", null, 500);
    }
}