<?php

class User
{
    private $conn;
    private $table = "users";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // CREATE
    public function create($name, $email)
    {
        $query = "INSERT INTO {$this->table} (name, email) VALUES (?, ?)";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $name, $email);

        return $stmt->execute();
    }

    // READ ALL
    public function getAll()
    {
        $query = "SELECT * FROM {$this->table} ORDER BY id DESC";

        $result = $this->conn->query($query);

        $users = [];

        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }

        return $users;
    }

    // READ SINGLE
    public function getById($id)
    {
        $query = "SELECT * FROM {$this->table} WHERE id = ?";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);

        $stmt->execute();

        $result = $stmt->get_result();

        return $result->fetch_assoc();
    }

    // UPDATE
    public function update($id, $name, $email)
    {
        $query = "UPDATE {$this->table}
                  SET name = ?, email = ?
                  WHERE id = ?";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssi", $name, $email, $id);

        return $stmt->execute();
    }

    // DELETE
    public function delete($id)
    {
        $query = "DELETE FROM {$this->table} WHERE id = ?";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);

        return $stmt->execute();
    }
}