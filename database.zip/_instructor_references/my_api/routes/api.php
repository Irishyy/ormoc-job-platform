<?php

header("Content-Type: application/json");

// CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . "/../controllers/UserController.php";

$controller = new UserController();

$method = $_SERVER['REQUEST_METHOD'];

$data = json_decode(file_get_contents("php://input"), true);

$id = $_GET['id'] ?? null;

switch ($method) {

    case "GET":

        if ($id) {
            $controller->show($id);
        } else {
            $controller->index();
        }

        break;

    case "POST":

        $controller->store($data);

        break;

    case "PUT":

        if (!$id) {
            echo json_encode([
                "message" => "ID is required"
            ]);
            exit;
        }

        $controller->update($id, $data);

        break;

    case "DELETE":

        if (!$id) {
            echo json_encode([
                "message" => "ID is required"
            ]);
            exit;
        }

        $controller->destroy($id);

        break;

    default:

        http_response_code(405);

        echo json_encode([
            "message" => "Method Not Allowed"
        ]);

        break;
}