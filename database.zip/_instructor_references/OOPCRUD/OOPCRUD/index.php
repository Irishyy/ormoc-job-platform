<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <div class="con">
    <div>
      <h1>Welcome to My Website</h1>

      <br>
      <a href="./view/form.php">
        <button>Create User</button>
      </a>  
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/axios@1.16.1/dist/axios.min.js"></script>
  <script src="./assets/js/index.js"></script>
</body>
</html>
