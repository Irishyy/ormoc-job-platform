<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <div style="display: flex;">
    <div>
      <form id="create_user"> 
        <!-- we don't need the action attribute and use id instead since we will be retrieving the data in javascript and not manually passing the data to another php file -->
        <input type="text" placeholder="Name" name="name" autocomplete="given-name" id="name">
        <br>
        <input type="Number" placeholder="Age" name="age" id="age" autocomplete="off">
        <br>
        <input type="text" placeholder="Address" name="address" id="address"autocomplete="off">
        <br>
        <input type="submit" value="Submit">
      </form>
    </div>

    <div style="margin: 30px 0 0 100px">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>AGE</th>
            <th>ADDRESS</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody id="tbody">
        
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/axios@1.16.1/dist/axios.min.js"></script>
  <script src="../assets/js/form.js"></script>
  
</body>
</html>