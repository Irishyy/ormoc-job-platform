<?php
require "../config/DbConnection.php";
require "../model/User.php";

$db = new DatabaseConnection();
$user = new User($db->connect());

header('Content-Type: application/json');

$input = json_decode(file_get_contents("php://input"), true);

// json_decode is needed for conversion as axios sends data in json and we need an associative array (with true)/object (without true) in php. json -> associative array

if($_SERVER['REQUEST_METHOD'] === "POST") 
  {

    if($input['action'] === "insert") {
      echo json_encode($user->createUser($input['name'],$input['age'], $input['address']));
    }
  } 

if ($_SERVER['REQUEST_METHOD'] === "GET") 
  {
    echo json_encode($user->displayUser());
  }
 
if($_SERVER['REQUEST_METHOD'] === "POST" && $input['action'] === "getSpecificUser") 
  {
    echo json_encode($user->getUser($input['id']));
  }

if($_SERVER['REQUEST_METHOD'] === "PUT" && $input['action'] === "update") 
  {
    echo json_encode($user->updateUser($input['name'], $input['age'], $input['address'], $input['id'],));
  }

if ($_SERVER['REQUEST_METHOD'] === "DELETE") 
  {
    echo json_encode($user->deleteUSer($input['id']));
  }

?>