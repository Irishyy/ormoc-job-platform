<?php

class User {
  private $conn;

  function __construct($db)
  {
    $this->conn = $db;
  }

  public function createUser($name, $age, $address)
  {
    $sql = "INSERT INTO users(name, age, address) 
      VALUES (?, ?, ?)";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("sis", $name, $age, $address);

    // bind_params is to put values to the question mark, specify the type
    // s = string, i = integer

    $stmt->execute();

    return ["status" => "Success"];
  }

  public function displayUser() 
  {
    $array = array();

    $sql = "SELECT * FROM users";
    $result = $this->conn->query($sql);

    while($row = $result->fetch_assoc()) {
      $array[] = $row;
    }

    return $array;
  }

  public function getUser($id) {
    $sql = "SELECT * FROM users WHERE id = ? LIMIT 1";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $result = $stmt->get_result();
    return $result->fetch_assoc();
  }

  public function updateUser($name, $age, $address, $id) {
    $sql = "UPDATE users SET name = ?, age = ?, address = ? WHERE id = ?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("sisi", $name, $age, $address, $id);
    $stmt->execute();

    return ["status"=>"Update Successful"]; // Assoc array
  }

  public function deleteUser($id) {
    $sql = "DELETE FROM users WHERE id=?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    return ["status"=>"Delete Successful"]; // Assoc array
  }
}
?>