const form = document.getElementById("create_user");

form.addEventListener("submit", async(e)=> {
  e.preventDefault();

  const formData = new FormData(form);
  const data = Object.fromEntries(formData.entries());

  // console.log(data);

  const inputID = document.getElementById('InputID');

  const hiddenID = inputID ? parseInt(inputID.value) : null;

  if(hiddenID) 
  {
    const res = await axios.put("../controllers/UserController.php", {
      action: "update",
      id: hiddenID,
      name: data.name,
      age: data.age,
      address: data.address
    })

    console.log(res.data);
  } 
  else 
  {
    const res = await axios.post("../controllers/UserController.php", {
      action: "insert",
      name: data.name,
      age: data.age,
      address: data.address
    })

    console.log(res.data);
  }
  
  display();
  // controllers become api since we wil be requesting using axios and sending to controllers serve as server
  // async waits for data before continuing
});


async function display()
{
  const tbody = document.getElementById('tbody');
  tbody.innerHTML = "";

  try {
    const res = await axios.get("../controllers/UserController.php");

      if(res.status === 200) {
        // console.log(res.data);
        
        let data = res.data;
        data.forEach(e => {
          const tr = document.createElement('tr');
          const td = `
            <td>${e.id}</td>
            <td>${e.name}</td>
            <td>${e.age}</td>
            <td>${e.address}</td>
            <td>
              <button onclick="deleteUser(${e.id}, this)">Delete</button>
              <button onclick="displayUserData(${e.id})">Update</button>
            </td>
          `;

          tr.innerHTML = td;
          tbody.appendChild(tr);
        });
      }
  } catch(err) {
    console.log(err);
  }
}

display();

async function displayUserData(id) {
  // console.log(id);

  try {
    const res = await axios.post("../controllers/UserController.php", {
      action: "getSpecificUser",
      id: id,
    });

    if(res.status===200) {
      // console.log("Get specific user", res.data);
      const form = document.getElementById('create_user');

      const data = res.data;
      const name = document.getElementById("name").value=data.name;
      const age = document.getElementById("age").value=data.age;
      const address = document.getElementById("address").value=data.address;

      const hiddenID = document.getElementById('InputID');

      if(hiddenID)
      {
        hiddenID.remove();
      }

      const id = document.createElement('input');
      id.value = data.id;
      id.id = "InputID"; // Input element's id
      id.disabled = true;
      id.type = "hidden";
      form.appendChild(id);

    }

  } catch(err) {
    console.log(err);
  }
}

async function deleteUser(id, btn) {

  try {
    const res = await axios.delete("../controllers/UserController.php", {
      data: {id: id}
    })

    if(res.status === 200) {
      console.log(res.data);

      const row = btn.closest('tr');
      row.remove();
    }
  }
  catch(err) {
    console.log(err);
  }
  
  display();
}