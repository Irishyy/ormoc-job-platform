<?php
class DatabaseConnection {
  private $host = "localhost";
  private $user = "root";  
  private $pass = "";
  private $db = "oopcrud";

  private $conn;
  // function that connects this app to the db

  public function connect()
  {
    $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->db); // mysql improved

    // if($this->conn) {
    //   echo "Connected!";
    // }

    if ($this->conn->connect_error){
      die("Connection failed" + $this->conn->connect_error);
    }

    return $this->conn;
  }
}

$DbConn = new DatabaseConnection();
$DbConn->connect();
?>