<?php
session_start();

header("Content-Type: application/json");

$action = isset($_GET['action']) ? $_GET['action'] : '';
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
  // Read the raw JSON payload coming from your Axios requests
  $jsonData = json_decode(file_get_contents("php://input"), true);

  if (!$jsonData) {
    echo json_encode(["status" => "error", "message" => "Invalid JSON data sent."]);
    exit;
  }

  require_once __DIR__ . "/../controllers/AuthController.php";
  $auth = new AuthController();

  switch ($action) {
    case 'oauth_login':
      $auth->handleGoogleLogin($jsonData);
      break;

    case 'manual_signup':
      $auth->handleManualSignUp($jsonData);
      break;

    case 'manual_login':
      $auth->handleManualLogin($jsonData);
      break;

    default:
      echo json_encode(["status" => "error", "message" => "Invalid endpoint"]);
      break;
  }
} else {
  echo json_encode(["status" => "error", "message" => "Method not allowed"]);
}
